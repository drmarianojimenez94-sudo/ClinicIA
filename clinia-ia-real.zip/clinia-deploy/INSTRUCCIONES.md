# ClinIA — Conectar la IA real (desde el iPhone, sin computadora)

## Qué hay en esta carpeta
- `index.html` → la app (idéntica a la que ya tenías, con el motor de reglas como respaldo)
- `netlify/functions/structure-consulta.js` → función que estructura la consulta con la IA real
- `netlify/functions/extract-patient.js` → función que completa la ficha del paciente con la IA real
- `netlify.toml` → le dice a Netlify dónde están las funciones

## Paso 1 — Subir el código a GitHub
1. Entrá a **github.com** desde Safari, creá una cuenta gratis (si no tenés).
2. Arriba a la derecha, tocá **+** → **New repository**.
3. Nombre: `clinia` (o el que quieras). Dejalo "Public" o "Private", da igual. Tocá **Create repository**.
4. Vas a ver una página vacía con un link **"uploading an existing file"**. Tocalo.
5. Subí los 4 archivos de esta carpeta (`index.html`, `netlify.toml`, y los dos `.js` de adentro de `netlify/functions/` — si el subidor de GitHub no te deja mantener carpetas, subí igual, y si hace falta creamos las carpetas manualmente, avisame).
6. Tocá **Commit changes**.

## Paso 2 — Conectar Netlify a ese repositorio
1. Entrá a **netlify.com**, creá una cuenta (podés usar la misma cuenta de GitHub para entrar, es un botón).
2. Tocá **Add new site** → **Import an existing project**.
3. Elegí **GitHub** y autorizá el acceso.
4. Elegí el repositorio `clinia` que creaste.
5. Dejá la configuración como está (Netlify va a detectar `netlify.toml` solo) y tocá **Deploy**.
6. En un minuto te da un link tipo `algo-random.netlify.app`. Ese es tu nuevo link — usalo en vez del anterior.

## Paso 3 — Cargar tu clave de la API de Claude
1. Entrá a **console.anthropic.com**, creá una cuenta, cargá una tarjeta (te va a pedir un mínimo, pero el uso real de esto cuesta centavos por consulta).
2. Ahí generás una **API key** (un texto largo que empieza con `sk-ant-...`). Copialo.
3. Volvé a Netlify → tu sitio → **Site configuration** → **Environment variables** → **Add a variable**.
4. Key: `ANTHROPIC_API_KEY` — Value: pegá tu clave. Guardar.
5. Importante: después de agregar la variable, hay que volver a desplegar para que tome efecto → **Deploys** → **Trigger deploy** → **Deploy site**.

## Paso 4 — Probar
Abrí tu link de Netlify, creá un paciente y hacé una consulta de prueba. Si algo falla, la app **no se rompe**: sigue funcionando con el motor de reglas de antes y te avisa con un cartel que no pudo usar la IA — fijate en ese caso que la clave esté bien pegada en el Paso 3.

## Si algo no encaja
Mandame una captura de la pantalla donde te trabaste (de GitHub o de Netlify) y seguimos desde ahí.
